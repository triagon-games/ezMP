#pragma once
#include "MPInterfacer.h"
class Server : public MPInterfacer
{
public:

};

