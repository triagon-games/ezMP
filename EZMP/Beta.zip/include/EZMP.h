#pragma once
#include "Client.h"
#include "MPInterfacer.h"
#include "Packet.h"

namespace EZMP
{
	int Init();
}